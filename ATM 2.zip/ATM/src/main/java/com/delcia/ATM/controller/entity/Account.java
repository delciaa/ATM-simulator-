package com.delcia.ATM.controller.entity;
import jakarta.persistence.*;

@Entity
@Table(name = "accounts")
public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, unique = true)
    private String accountNumber;
    @Column(nullable = false)
    private String name;
    @Column(nullable = false)
    private String pinCode; // Should be encrypted in a real app
    @Column(nullable = false)
    private double balance = 0.0;

    public Account(){}
    public Account(String accountNumber, String name, String pinCode, double balance) {
        this.accountNumber = accountNumber;
        this.name = name;
        this.pinCode = pinCode;
        this.balance = balance = 0.0;
    }
    // Getters
    public Long getId() { return id; }
    public String getAccountNumber() { return accountNumber; }
    public String getName() { return name; }
    public String getPinCode() { return pinCode; }
    public double getBalance() { return balance; }

    // Setters
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
    public void setName(String name) { this.name = name; }
    public void setPinCode(String pinCode) { this.pinCode = pinCode; }
    public void setBalance(double balance) {
        this.balance = balance;
    }

}
