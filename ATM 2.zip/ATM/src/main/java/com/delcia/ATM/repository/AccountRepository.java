package com.delcia.ATM.repository;
import com.delcia.ATM.controller.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {
        Account findByAccountNumber(String accountNumber);
        // Check if an account already exists based on account number
        boolean existsByAccountNumber(String accountNumber);
}
