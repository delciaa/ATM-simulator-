package com.delcia.ATM.controller;

import com.delcia.ATM.controller.entity.Account;
import com.delcia.ATM.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.security.auth.login.AccountNotFoundException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/atm")
public class ATMController {
    @Autowired
    private AccountService accountService;

    // home page
    @GetMapping("/")
    public String home() {
        return "index";
    }

    // Load create account page
    @GetMapping("/create")
    public String showCreateAccountPage() {
        return "create";
    }

    // Process new account creation
    @PostMapping("/create")
    public String createAccount(@RequestParam String name,
                                @RequestParam String accountNumber,
                                @RequestParam String pinCode,
                                Model model) {
        String errorMessage = accountService.createAccount(name, accountNumber, pinCode);
        if (errorMessage != null) {
            model.addAttribute("errorMessage", errorMessage);
            return "create"; // Reload the form with the error message
        }
        return "redirect:/atm/login"; // Redirect to login after successful creation
    }

    // Load login page
    @GetMapping("/login")
    public String showLoginPage() {
        return "login"; // Maps to login.html
    }

    @PostMapping("/login")
    public String login(@RequestParam String accountNumber,
                        @RequestParam String pinCode,
                        Model model) {
        String errorMessage = accountService.login(accountNumber, pinCode);

        if (errorMessage != null) {
            model.addAttribute("errorMessage", errorMessage);
            return "login"; // Reload login page with error message
        }
/*
        // Successful login, store account number in session
        HttpSession session = request.getSession();
        session.setAttribute("accountNumber", accountNumber);  // Storing accountNumber in session
*/
        // Redirect to account dashboard
        return "redirect:/atm/dashboard"; // Assuming a dashboard page exists
    }

    @GetMapping("/dashboard")
    public String showDashboard() {
        return "dashboard"; // Returns the dashboard.html template
    }

    /*
    @GetMapping("/dashboard")
    public String dashboardPage(HttpSession session, Model model) {
        // Retrieve the logged-in user's account number from session
        String accountNumber = (String) session.getAttribute("accountNumber");
        // Fetch the user's name using the service
        String userName = accountService.getUserNameByAccountNumber(accountNumber);

        if (userName != null) {
            model.addAttribute("userName", userName);  // Add the username to the model
        } else {
            model.addAttribute("errorMessage", "Account not found.");
        }

        return "dashboard"; // Dashboard page where you display the user's name
    }
    */

    @GetMapping("/deposit")
    public String depositPage() {
        return "deposit"; // Deposit money page
    }

    // Handle deposit form submission
    @PostMapping("/deposit")
    public String handleDeposit(
            @RequestParam("accountNumber") String accountNumber,
            @RequestParam("amount") double amount,
            Model model) {
        // Call the deposit method from the service
        String errorMessage = accountService.deposit(accountNumber, amount);
        if (errorMessage != null) {
            // Pass error message to the view (HTML template)
            model.addAttribute("errorMessage", errorMessage);
            return "deposit"; // Return to the deposit page if there's an error
        }
        // If no error, show success message
        model.addAttribute("successMessage", "Deposit successful.");
        return "deposit"; // Return to the deposit page or redirect to another page if needed
    }

    @GetMapping("/withdraw")
    public String withdraw() {
        return "withdraw"; // Deposit money page
    }

    // Handle withdraw request and return appropriate template
    @PostMapping("/withdraw")
    public String withdraw(@RequestParam String accountNumber,
                           @RequestParam double amount,
                           Model model) {

        String errorMessage = accountService.withdraw(accountNumber, amount);

        if (errorMessage != null) {
            model.addAttribute("errorMessage", errorMessage); // Add error message if withdrawal failed
            return "withdraw"; // Return withdraw page with error message
        }

        model.addAttribute("successMessage", "Withdrawal successful!"); // Success message
        return "dashboard"; // Redirect to dashboard or another appropriate page after successful withdrawal
    }

    @GetMapping("/changePin")
    public String showChangePinForm() {
        return "changepin"; // This renders changePin.html
    }

    @PostMapping("/changePin")
    public String changePin(@RequestParam String accountNumber,
                            @RequestParam String currentPin,
                            @RequestParam String newPin,
                            @RequestParam String confirmPin,
                            Model model) {

        if (!newPin.equals(confirmPin)) {
            model.addAttribute("errorMessage", "New PIN and Confirm PIN do not match.");
            return "changepin";
        }

        String errorMessage = accountService.changePin(accountNumber, currentPin, newPin);

        if (errorMessage != null) {
            model.addAttribute("errorMessage", errorMessage);
            return "changepin";
        }

        model.addAttribute("successMessage", "PIN changed successfully.");
        return "dashboard";
    }

    @GetMapping("/balance")
    public String showBalancePage() {
        return "balance";  // Load the balance page where users can enter their account number
    }

    @PostMapping("/balance")
    public String checkBalance(@RequestParam String accountNumber, Model model) {
        if (accountNumber.isEmpty()) {
            model.addAttribute("errorMessage", "Please enter an account number.");
            return "balance";
        }

        try {
            // Fetch balance from the service
            double balance = accountService.getBalance(accountNumber);
            model.addAttribute("balance", balance);
        } catch (AccountNotFoundException e) {
            model.addAttribute("errorMessage", "Account not found. Please check your account number.");
        } catch (Exception e) {
            model.addAttribute("errorMessage", "An unexpected error occurred. Please try again later.");
        }

        return "balance"; // Always return the balance page
    }

    @GetMapping("/transfers")
    public String showTransferPage() {
        return "transfer"; // Returns the transfer page
    }

    @PostMapping("/transfers")
    public String processTransfer(
            @RequestParam String fromAccount,
            @RequestParam String toAccount,
            @RequestParam double amount,
            Model model) {

        String resultMessage = accountService.transferMoney(fromAccount, toAccount, amount);

        if (resultMessage.startsWith("Transfer successful")) {
            model.addAttribute("successMessage", resultMessage);
        } else {
            model.addAttribute("errorMessage", resultMessage);
        }

        return "transfer"; // Always return the transfer page
    }

    @GetMapping("/logout")
    public String logout() {
        return "redirect:/atm/login"; // Redirects to login page
    }
}
