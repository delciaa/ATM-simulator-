package com.delcia.ATM.service;
import com.delcia.ATM.controller.entity.Account;
import com.delcia.ATM.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.security.auth.login.AccountNotFoundException;
import java.util.HashMap;
import java.util.Map;

@Service
public class AccountService {
    @Autowired
    private AccountRepository accountRepository;
    // Map to track failed login attempts
    private Map<String, Integer> failedAttempts = new HashMap<>();

    public void saveAccount(Account account) {
        accountRepository.save(account);
    }

    // Method to create a new account
    public String createAccount(String name, String accountNumber, String pinCode) {
        Account existingAccount = accountRepository.findByAccountNumber(accountNumber);
        if (accountRepository.existsByAccountNumber(accountNumber)) {
            return "An account with this number already exists!";
        }

        Account account = new Account();
        account.setName(name);
        account.setAccountNumber(accountNumber);
        account.setPinCode(pinCode);
        accountRepository.save(account);
        return null; // No error message means success
    }

    // Login method
    public String login(String accountNumber, String pinCode) {
        // Find the account from the database
        Account account = accountRepository.findByAccountNumber(accountNumber);

        // If the account doesn't exist
        if (account == null) {
            return "Account number not found. Please, go back to create an account.";
        }

        // Check if the user has failed 3 times
        if (failedAttempts.getOrDefault(accountNumber, 0) >= 3) {
            return "Too many failed attempts. Please go back to the welcome page.";
        }

        // Validate the PIN
        if (!account.getPinCode().equals(pinCode)) {
            failedAttempts.put(accountNumber, failedAttempts.getOrDefault(accountNumber, 0) + 1);
            return "Incorrect PIN. Try again.";
        }

        // Reset failed attempts on successful login
        failedAttempts.put(accountNumber, 0);

        return null; // No error message, login successful
    }

    public String getUserNameByAccountNumber(String accountNumber) {
        Account account = accountRepository.findByAccountNumber(accountNumber);
        if (account != null) {
            return account.getName();  // Return the user's name if the account is found
        } else {
            return null;  // Return null if the account is not found
        }
    }

    public String deposit(String accountNumber, double amount) {
        // Retrieve the user's account using the accountNumber
        Account account = accountRepository.findByAccountNumber(accountNumber);

        if (account == null) {
            return "Account not found.";
        }

        // Check if the amount is valid
        if (amount <= 0) {
            return "Deposit amount must be greater than zero.";
        }
        // Update the balance
        account.setBalance(account.getBalance() + amount);
        // Save the updated account (assuming there's a method for that)
        saveAccount(account);
        return null; // Return null if no errors
    }

    public String withdraw(String accountNumber, double amount) {
        Account account = accountRepository.findByAccountNumber(accountNumber);

        if (account != null && account.getBalance() >= amount) {
            account.setBalance(account.getBalance() - amount);
            accountRepository.save(account);
            return "Withdrawal successful";
        }

        return "Insufficient balance or account not found";
    }

    // Change PIN method
    public String changePin(String accountNumber, String oldPin, String newPin) {
        // Retrieve the user's account using the accountNumber
        Account account = accountRepository.findByAccountNumber(accountNumber);

        if (account == null) {
            return "Account not found.";
        }

        // Check if the old PIN is correct
        if (!account.getPinCode().equals(oldPin)) {
            return "Incorrect old PIN.";
        }

        // Validate the new PIN (you can add more validation, like length checks)
        if (newPin.length() < 4) {
            return "New PIN must be at least 4 characters long.";
        }

        // Update the PIN
        account.setPinCode(newPin);
        // Save the updated account
        accountRepository.save(account);
        return null; // Return null if no errors
    }


    public double getBalance(String accountNumber) throws AccountNotFoundException {
        // Fetch the account from the database by account number
        Account account = accountRepository.findByAccountNumber(accountNumber);

        // Check if account exists
        if (account != null) {
            return account.getBalance();  // Return the balance of the account
        } else {
            // Handle account not found, could throw an exception or return a default value
            throw new AccountNotFoundException("Account not found.");
        }
    }

    public String transferMoney(String accountNumber, String toAccount, double amount) {
        // Find the sender's account
        Account account = accountRepository.findByAccountNumber(accountNumber);

        if (account == null) {
            return "Account not found.";
        }

        // Check if sender has enough balance
        if (account.getBalance() < amount) {
            return "Insufficient funds.";
        }

        // Deduct the amount from sender's account
        account.setBalance(account.getBalance() - amount);
        accountRepository.save(account);

        return "Transfer successful! The amount has been sent to " + toAccount;
    }


}
